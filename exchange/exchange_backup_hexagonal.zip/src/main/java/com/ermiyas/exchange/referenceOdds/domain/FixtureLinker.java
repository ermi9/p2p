package com.ermiyas.exchange.referenceOdds.domain;

public class FixtureLinker {
    
}
