package com.ermiyas.exchange.referenceOdds.application;

import com.ermiyas.exchange.referenceOdds.domain.Fixture;
import com.ermiyas.exchange.referenceOdds.infrastructure.FixtureService;
import com.ermiyas.exchange.infrastructure.persistence.entity.EventEntity;
import com.ermiyas.exchange.infrastructure.persistence.entity.FixtureProviderMappingEntity;
import com.ermiyas.exchange.infrastructure.persistence.jpa.EventJpaRepository;
import com.ermiyas.exchange.infrastructure.persistence.jpa.FixtureProviderMappingJpaRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class AdminSyncService {

    private final FixtureService fixtureService;
    private final EventJpaRepository eventRepository;
    private final FixtureProviderMappingJpaRepository mappingRepository;

    @Transactional
    public void syncAllFixtures() {
        log.info("Admin Action: Starting manual fixture synchronization...");
        
        // 1. Fetch from the Top 5 Leagues via the FixtureService you provided
        List<Fixture> externalFixtures = fixtureService.getTop5Leagues();
        
        int newEventsCount = 0;

        for (Fixture f : externalFixtures) {
            // 2. Check if the event exists using the external_id column
            if (!eventRepository.existsByExternalId(f.id())) {
                
                // 3. Map Fixture Record -> EventEntity
                EventEntity eventEntity = EventEntity.builder()
                        .externalId(f.id())
                        .name(f.homeTeam() + " vs " + f.awayTeam()) // Combines teams into the 'name' column
                        .startTime(f.startTime())
                        .leagueCode(f.league().name())
                        .status("OPEN")
                        .build();

                EventEntity savedEvent = eventRepository.save(eventEntity);

                // 4. Create the mapping entry so the Odds Crawler can find this event later
                FixtureProviderMappingEntity mapping = FixtureProviderMappingEntity.builder()
                        .event(savedEvent)
                        .providerName("THE_ODDS_API")
                        .externalFixtureId(f.id())
                        .build();
                
                mappingRepository.save(mapping);
                newEventsCount++;
            }
        }
        
        log.info("Synchronization complete. Added {} new events and mappings.", newEventsCount);
    }
}