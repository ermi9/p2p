package com.ermiyas.exchange.domain.settlement;
//DOmain enum to declare winning side during settlement
public enum BetSide {
    MAKER,
    TAKER
}
