package com.ermiyas.exchange.infrastructure.api;

import com.ermiyas.exchange.referenceOdds.application.AdminSyncService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final AdminSyncService adminSyncService;

    @PostMapping("/sync-fixtures")
    public ResponseEntity<?> triggerManualSync() {
        try {
            adminSyncService.syncAllFixtures();
            return ResponseEntity.ok(Map.of(
                "status", "success",
                "message", "Database synchronization triggered successfully."
            ));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of(
                "status", "error",
                "message", e.getMessage()
            ));
        }
    }
}