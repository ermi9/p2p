package com.ermiyas.exchange.referenceOdds.domain;

public enum League {
    PL, CL, BL1, SA, PD, FL1 // Football-Data.org codes
}