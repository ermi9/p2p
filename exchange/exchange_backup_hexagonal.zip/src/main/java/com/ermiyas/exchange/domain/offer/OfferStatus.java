package com.ermiyas.exchange.domain.offer;

public enum OfferStatus{
    OPEN,
    PARTIALLY_TAKEN,
    TAKEN,
    CANCELLED,
    SETTLED
}