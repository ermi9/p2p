package com.ermiyas.exchange.domain.orderbook;

public class OrderBookException extends RuntimeException {
    public OrderBookException(String message) {
        super(message);
    }
}
