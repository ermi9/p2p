package com.ermiyas.exchange.referenceOdds.domain;

import com.ermiyas.exchange.infrastructure.persistence.jpa.FixtureProviderMappingJpaRepository;
import com.ermiyas.exchange.infrastructure.persistence.jpa.EventJpaRepository;
import com.ermiyas.exchange.infrastructure.persistence.entity.FixtureProviderMappingEntity;
import com.ermiyas.exchange.infrastructure.persistence.entity.EventEntity;
import com.ermiyas.exchange.referenceOdds.infrastructure.external.TheOddsApiDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReferenceOddsService {

    private final ReferenceOddsRepository repository;
    private final FixtureProviderMappingJpaRepository mappingRepository;
    private final EventJpaRepository eventRepository;

    @Transactional
    public void ingestAndLinkOdds(TheOddsApiDto externalMatch) {
        // 1. Try to find mapping by ID (Highest Precision)
        Long internalEventId = findByMapping(externalMatch.id());

        // 2. FALLBACK: Try to find by Team Names (Matching "Arsenal" to "Arsenal vs Liverpool")
        if (internalEventId == null) {
            internalEventId = findByNameMatch(externalMatch.homeTeam(), externalMatch.awayTeam());
        }

        if (internalEventId != null) {
            // Corrected method calls to match your record: homeTeam() and awayTeam()
            List<OddsSnapshot> snapshots = externalMatch.toSnapshots(internalEventId);
            
            if (!snapshots.isEmpty()) {
                repository.saveAll(snapshots);
                log.info("MATCHED: {} vs {} linked to Event ID: {}", 
                    externalMatch.homeTeam(), externalMatch.awayTeam(), internalEventId);
            }
        } else {
            log.warn("SKIPPING: No database match found for API fixture: {} vs {}", 
                externalMatch.homeTeam(), externalMatch.awayTeam());
        }
    }

    private Long findByMapping(String externalId) {
        FixtureProviderMappingEntity mapping = mappingRepository.findByExternalFixtureId(externalId);
        return (mapping != null) ? mapping.getEvent().getId() : null;
    }

    private Long findByNameMatch(String home, String away) {
        if (home == null || away == null) return null;
        
        // Searches all 'OPEN' events for a name that contains both teams
        return eventRepository.findAll().stream()
            .filter(e -> "OPEN".equals(e.getStatus()))
            .filter(e -> isFuzzyMatch(e.getName(), home, away))
            .map(EventEntity::getId)
            .findFirst()
            .orElse(null);
    }

    private boolean isFuzzyMatch(String dbEventName, String apiHome, String apiAway) {
        String lowerEvent = dbEventName.toLowerCase();
        String lowerHome = apiHome.toLowerCase();
        String lowerAway = apiAway.toLowerCase();
        
        // Success if the DB name "Team A vs Team B" contains both API names
        return lowerEvent.contains(lowerHome) && lowerEvent.contains(lowerAway);
    }
}