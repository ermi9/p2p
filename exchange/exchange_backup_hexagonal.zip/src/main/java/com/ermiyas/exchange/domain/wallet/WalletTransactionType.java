package com.ermiyas.exchange.domain.wallet;

public enum WalletTransactionType {
    DEPOSIT,
    WITHDRAWAL,
    BET_DEBIT,
    BET_CREDIT
}
