package com.ermiyas.exchange.infrastructure.persistence.jpa;

public class WalletTransactionsJpaRepository {
    
}
